# todo_list

Example Todo List Application 
Jan 29, 2018

Icons based on open source PNG icons from here: 

    https://github.com/iconic/open-iconic/tree/master/png
